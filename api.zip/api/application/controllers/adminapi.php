<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');
 header("Access-Control-Allow-Methods: HTTP, GET, POST, OPTIONS, PUT, DELETE");
 header('Access-Control-Allow-Headers: Content-Type, Content-Range, Content-Disposition, Content-Description');
require(APPPATH.'libraries/REST_Controller.php');
class Adminapi extends REST_Controller
{
	const ADMIN_API = "adminapi_model";
	function __construct()
	{
		parent::__construct();
		$this->response->format = 'json';
		$this->load->model(self::ADMIN_API);
				ini_set('date.timezone', 'Asia/Calcutta');
	}

	/**
	* API functions
	*/
	function slider_get()
	{
		$model = self::ADMIN_API;
		$slider = $this->$model->slider_details();
		foreach($slider as $sli)
	  {
	  	$result[]=array(
								'slider_id' => $sli['slider_id'],
								'image'    => base_url()."assets/img/slider/".$sli['image'],
								'active'      => $sli['active']
							);
		}
		if ($result)
		{
			$this->response(array(
	                        'success' => true,
	                        'responsedata' => $result,
	                        'message' => 'Data Getted successfully'
	                    ), REST_Controller::HTTP_OK);
		}
		else
		{
			$this->response(array(
                'success' => false,
                'message' => 'Data Not Getted'
            ), REST_Controller::HTTP_BAD_REQUEST);
		}
	}
	function brand_get()
	{
		$model = self::ADMIN_API;
		$brand = $this->$model->brand_details();
		foreach($brand as $b)
	  {
	  	$result[]=array(
								'brand_id' => $b['brand_id'],
								'brand_name' => $b['brand_name'],
								'image'    => base_url()."assets/img/brand/".$b['image'],
								'active'      => $b['active']
							);
		}
		if ($result)
		{
					$this->response(array(
	                        'success' => true,
	                        'responsedata' => $result,
	                        'message' => 'Data Getted successfully'
	                    ), REST_Controller::HTTP_OK);
		}
		else
		{
			$this->response(array(
                'success' => false,
                'message' => 'Data Not Getted'
            ), REST_Controller::HTTP_BAD_REQUEST);
		}
	}
	function product_get()
	{
		$model = self::ADMIN_API;
		$product = $this->$model->product_details();
		foreach($product as $pro)
	  {
	  			$result[]=array(
								'product_id' => $pro['product_id'],
								'product_name' => $pro['product_name'],
								'price' => $pro['price'],
								'image'    => base_url()."assets/img/product/".$pro['image'],
								'active'      => $pro['active']
							);
		}
		if ($result)
		{
					$this->response(array(
	                        'success' => true,
	                        'responsedata' => $result,
	                        'message' => 'Data Getted successfully'
	                    ), REST_Controller::HTTP_OK);
		}
		else
		{
			$this->response(array(
                'success' => false,
                'message' => 'Data Not Getted'
            ), REST_Controller::HTTP_BAD_REQUEST);
		}
	}

}
?>
