<?php
if( ! defined('BASEPATH')) exit('No direct script access allowed');
class Adminapi_model extends CI_Model
{
	function __construct()
    {
        parent::__construct();
	}


	function slider_details()
	{
		$sql = "select * from slider where active=1";
		$result = $this->db->query($sql);
		return $result->result_array();
	}
	function brand_details()
	{
		$sql = "select * from brand where active=1";
		$result = $this->db->query($sql);
		return $result->result_array();
	}
	function product_details()
	{
		$sql = "select * from product where active=1";
		$result = $this->db->query($sql);
		return $result->result_array();
	}
}
?>
