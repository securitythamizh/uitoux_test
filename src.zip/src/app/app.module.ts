import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ToastrModule } from 'ngx-toastr';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule, HttpClient, HTTP_INTERCEPTORS,HttpErrorResponse } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppComponent } from './app.component';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
//import { LayoutModule } from '@angular/cdk/layout';
import { OverlayModule } from '@angular/cdk/overlay';
import {MatButtonModule, MatCardModule, MatIconModule, MatTableModule,MatCheckboxModule, MatInputModule,MatToolbarModule,MatMenuModule,MatAutocompleteModule,MatTooltipModule,MatDialogModule,MatGridListModule,MatListModule,MatSidenavModule,MatFormFieldModule,MatProgressSpinnerModule} from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { CommonapiService } from './shared/services/commonapi.service';
import { httpSetHeaders, LoaderInterceptor } from './interceptor/httpSetHeaders.interceptor';

import {TranslateModule, TranslateLoader} from '@ngx-translate/core';
import {TranslateHttpLoader} from '@ngx-translate/http-loader';

// AoT requires an exported function for factories
export function HttpLoaderFactory(httpClient: HttpClient) {
  return new TranslateHttpLoader(httpClient);
}

@NgModule({
  imports: [
    BrowserModule,
    AppRoutingModule,
	//LayoutModule,
	OverlayModule,
	HttpClientModule,
	BrowserAnimationsModule,
	MatProgressSpinnerModule,
	ToastrModule.forRoot({
	timeOut: 3000,
	preventDuplicates: true,
   }),
	MatButtonModule,
	MatIconModule,
	MatListModule,
	MatSidenavModule,
	MatToolbarModule,
	MatCardModule,
	MatFormFieldModule,
	MatDialogModule,
	MatTooltipModule,
	  TranslateModule.forRoot({
	  loader: {
		provide: TranslateLoader,
		useFactory: HttpLoaderFactory,
		deps: [HttpClient]
	  }
	})
  ],
   declarations: [
    AppComponent
  ],
  providers: [

    CommonapiService,
    ToastrService,
    // { provide: HTTP_INTERCEPTORS, useClass: httpSetHeaders, multi: true },
    // {provide: LocationStrategy, useClass: HashLocationStrategy},
    // { provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptor, multi: true }

  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
