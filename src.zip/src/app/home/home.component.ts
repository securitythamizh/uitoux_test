import { Component, OnInit,ViewChild,ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { HomeService } from './home.service';
@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  data;
  slider =[];
  brands =[];
  products =[];
    constructor(private router: Router,private homeService: HomeService) {

	}
    ngOnInit() {
this.getslider();
this.getbrand();
this.getproduct();
	}
  getslider() {
        this.homeService.getslider('adminapi/slider').subscribe((data) => {
          console.log(data);

            this.slider = data['responsedata'];
    } );
    }
    getbrand() {
          this.homeService.getbrand('adminapi/brand').subscribe((data) => {
              this.brands = data['responsedata'];
      } );
      }
      getproduct() {
            this.homeService.getproduct('adminapi/product').subscribe((data) => {
                this.products = data['responsedata'];
        } );
        }

}
