import { Component, OnInit,ViewChild,ElementRef,Injectable } from '@angular/core';
import {HttpRequest,HttpEvent, HttpClient, HttpErrorResponse, HttpHeaders,HttpBackend} from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
import { Observable } from 'rxjs';
//import { environment } from '../../../environments/environment';
import { map } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';
@Injectable({
  providedIn: 'root'
})
export class HomeService {
  apiURL: string = "http://localhost/api/index.php/";
  BaseURL: string = "http://localhost/api/";
  accessData;
  private headers = new HttpHeaders({ 'Content-Type': 'application/json; charset=UTF-8;' });
  private headers_multi = new HttpHeaders({ 'Content-Type': 'multipart/form-data'});
  constructor(private httpClient: HttpClient, private toastr: ToastrService){}
  public getslider(url: string) {
    return this.httpClient
      .get(this.apiURL + url).pipe(
        map((response) => {
          // some response manipulation
          let result = response;
          return result;
        }));
  }
  public getbrand(url: string) {
    return this.httpClient
      .get(this.apiURL + url).pipe(
        map((response) => {
          // some response manipulation
          let result = response;
          return result;
        }));
  }
  public getproduct(url: string) {
    return this.httpClient
      .get(this.apiURL + url).pipe(
        map((response) => {
          // some response manipulation
          let result = response;
          return result;
        }));
  }
}
