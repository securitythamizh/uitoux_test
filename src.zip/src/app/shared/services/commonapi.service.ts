import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { map } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';

@Injectable({
  providedIn: 'root'
})

export class CommonapiService {
  apiURL: string = "http://localhost/api/index.php/";
  BaseURL: string = "http://localhost/api/";

  public isLoading = new BehaviorSubject(false);
  public newUserDetails: any = {};
  public currentUSerDetails: any = {};

  //User Component Customer Records Pass Form Features Component With Relation ship

   public userrecords_detalis         = new BehaviorSubject<Object>(Object);

  private headers = new HttpHeaders({ 'Content-Type': 'application/json; charset=UTF-8;' });
  private headers_multi = new HttpHeaders({ 'Content-Type': 'multipart/form-data'});
  constructor(private httpClient: HttpClient, private toastr: ToastrService) { }
}
